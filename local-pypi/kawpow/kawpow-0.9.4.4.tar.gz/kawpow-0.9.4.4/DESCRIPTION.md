# Kawpow

> C/C++ implementation of Kawpow – the Ravencoin Proof of Work algorithm

## Usage

Currently only light verification is supported

```final_hash = kawpow.light_verify( bytes(header_hash), bytes(mix_hash), nonce )```

